///////////////////////// HashTable ////////////////////////////
//
// Title: HashTable
// Course: CS 400, Summer 2020
//
// Author: Aditya Arun
// Email: aarun2@wisc.edu
// Lecturer's Name: Florian Heimerl
//
///////////////////////////////////////////////////////////
package application;

/**
 * This method creates a Hash table using the built in java hash code method. Each element of this
 * class is of inner class type list node. So it is an array of linked nodes. Each node has two
 * corresponding deepHashTable and the next node along with the name and count of the element. This
 * class is package private so only files in application can access it. Also, methods accessible are
 * package protected.
 * 
 * @author Aditya
 *
 */
class HashTable {
  private double loadFactorThreshold; // threshold for main table
  private int numItems; // unique(by name) items in table
  private ListNode table[]; // the table or array

  /**
   * This is a private inner class and each node in the main table is of this type. The
   * DeepHashTables store associated values.
   * 
   * @author Aditya
   *
   */
  private class ListNode {
    private int count; // the number of times the name has been added to the table
    private String name;
    // table for the other data types
    private DeepHashTable table1; // it will have count number of non-unique(by name) items
    private DeepHashTable table2; // it will have count number of non-unique(by name) items
    private ListNode next; // to get to next in list

    /**
     * A constructor to initialize fields for the node.
     * 
     * @param name  node's name
     * @param data1 node's first corresponding data's value
     * @param data2 node's second corresponding data's value
     */
    private ListNode(String name, String data1, String data2) {
      this.name = name;
      this.next = null;
      this.table1 = new DeepHashTable(); // first time, create table
      this.table1.deepInsert(data1);
      this.table2 = new DeepHashTable(); // first time, create table
      this.table2.deepInsert(data2);
      this.count = 1;
    }

    /**
     * A special constructor to quickly initialize fields when saving a node that was created
     * before.
     * 
     * @param name   node's name
     * @param count  node's count
     * @param table1 first table for first corresponding value
     * @param table2 second table for second corresponding value
     */
    private ListNode(String name, int count, DeepHashTable table1, DeepHashTable table2) {
      this.name = name;
      this.count = count;
      this.table1 = table1; // store table
      this.table2 = table2; // store table
      this.next = null;
    }
  }

  /**
   * A private inner class that represents the node in the deepHashTable.
   * 
   * @author Aditya
   *
   */
  private class DeepNode {
    private int deepCount; // the number of times the name has been added to the table
    private String deepName;
    private DeepNode deepNext; // for the next item if present

    /**
     * A constructor to initialize fields of the deepNode
     * 
     * @param name name of deepNode
     */
    private DeepNode(String name) {
      this.deepName = name;
      this.deepNext = null;
      this.deepCount = 1; // added once
    }
  }

  /**
   * A private inner class that implements a basic hashTable with an array of linked nodes as the
   * table. Each node has a count and the name is used to generate the hashCode using java's
   * hashCode method. Nodes have a next item to store next node if there is a collision.
   * 
   * @author Aditya
   *
   */
  private class DeepHashTable {
    private double deepLfThreshold; // threshold for the table
    private int deepNumItems; // number of unique items(by name) in table
    private DeepNode deepTable[]; // the table or array

    /**
     * A constructor that initializes the threshold to 0.75 and sets the table to size 16
     */
    private DeepHashTable() {
      this.deepLfThreshold = 0.75;
      this.deepNumItems = 0; // as no items yet
      this.deepTable = new DeepNode[16];
    }

    /**
     * A method that lets me insert an item into the table
     * 
     * @param name name of item to insert
     */
    private void deepInsert(String name) {
      deepInsert(deepTable, name, -1); // -1 indicates, we are not rehashing
      double deepLoadFactor = ((double) deepNumItems) / deepTable.length;
      if (deepLoadFactor >= deepLfThreshold) // full table
        deepResize(); // resize and rehash
    }

    /**
     * This method helps us insert the item with the name into the given table. If the count is
     * greater than 0, we are rehashing. When rehashing, we just want to save the given count and
     * not change the number of unique items as that doesn't change when rehashing. If item present,
     * increment the count for the item. Else, add it, to list at index given by hashCode.
     * 
     * @param deepTableAdd table to add item to
     * @param name         name of item to add
     * @param count        -1 if not rehashing else as count for any node is 1 or more, count is
     *                     also 1 or more when rehashing
     */
    private void deepInsert(DeepNode deepTableAdd[], String name, int count) {
      int deepIndex = name.hashCode();
      deepIndex = Math.abs(deepIndex) % deepTableAdd.length; // get index
      DeepNode currDeepNode = deepTableAdd[deepIndex]; // get node where to add
      if (currDeepNode == null) { // add at null spot
        deepTableAdd[deepIndex] = new DeepNode(name); // first in list
        if (count > 0) // rehashing, want to save given count
          deepTableAdd[deepIndex].deepCount = count;
        else // not rehashing first unique item
          deepNumItems++; // brand new item
      } else { // something present at index
        if (currDeepNode.deepName.equals(name)) { // we are adding a non-unique item
          currDeepNode.deepCount++; // same shallow deep item pair is added
          return;
        }
        while (currDeepNode.deepNext != null) { // get to last node
          currDeepNode = currDeepNode.deepNext;
          if (currDeepNode.deepName.equals(name)) { // we are adding a non-unique item
            currDeepNode.deepCount++; // same shallow deep item pair is added
            return;
          }
        }
        currDeepNode.deepNext = new DeepNode(name); // next is new node
        if (count > 0) // rehashing, want to save given count
          currDeepNode.deepNext.deepCount = count;
        else // not rehashing first unique item
          deepNumItems++; // brand new item
      }
    }

    /**
     * This method helps resize and rehash the table. Double the table size and add 1.
     */
    private void deepResize() {
      DeepNode deepNewTable[] = new DeepNode[(2 * deepTable.length) + 1]; // new table
      // rehash
      int total = 0; // check till all items added
      for (int checkIndex = 0; (checkIndex < deepTable.length)
          && (total != deepNumItems); checkIndex++) { // find nodes to add
        DeepNode currNode = deepTable[checkIndex];
        while (currNode != null) { // insert node one by one
          // when rehashing we will be entering unique nodes as they were in old table which only
          // had unique nodes
          deepInsert(deepNewTable, currNode.deepName, currNode.deepCount);
          total++;
          currNode = currNode.deepNext; // get next node to add
        }
      }
      deepTable = deepNewTable; // set as new table
    }

    /**
     * A method that helps me to find node with name in the table. If the index with node has the
     * node after some other node. Pass that some other node. If the node is the first node or the
     * only node, pass that. This method will be used to delete this node. So, passing the previous
     * node if present will help me delete it by setting next to null. If node not found return
     * null.
     * 
     * @param name name of node to delete
     * @return null if not present, if first node at index, then the node else previous node
     */
    private DeepNode deepGet(String name) {
      int deepIndex = name.hashCode();
      deepIndex = Math.abs(name.hashCode()) % deepTable.length;
      DeepNode ret = deepTable[deepIndex];
      if (ret == null) // node not present
        return null;
      if (ret.deepName.equals(name)) { // node is first return it
        return ret;
      }
      while (ret.deepNext != null) {
        if (ret.deepNext.deepName.equals(name)) { // node not first
          return ret; // pass previous
        }
        ret = ret.deepNext;
      }
      return null;
    }
  }

  /**
   * A constructor for the main hashTable. Set threshold to 0.75, size to 16 and no items yet.
   */
  HashTable() {
    this.loadFactorThreshold = 0.75;
    this.numItems = 0;
    this.table = new ListNode[16];
  }

  /**
   * Helps the user insert a name, data1 and data2 pair by calling the helper insert method
   * 
   * @param name  the item's name
   * @param data1 the item's corresponding name of first data
   * @param data2 the item's corresponding name of second data
   */
  void insert(String name, String data1, String data2) {
    insert(table, name, data1, data2);
    double loadFactor = ((double) numItems) / table.length;
    if (loadFactor >= loadFactorThreshold) // full table
      resize(); // resize and rehash
  }

  /**
   * A helper method to insert the given name, data1 and data2 pair to the given table.
   * 
   * @param tableAdd table to add item to
   * @param name     name of item to add
   * @param data1    first corresponding data to add
   * @param data2    second corresponding data to add
   */
  private void insert(ListNode tableAdd[], String name, String data1, String data2) {
    int hashIndex = name.hashCode();
    hashIndex = Math.abs(hashIndex) % tableAdd.length;
    ListNode currNode = tableAdd[hashIndex];
    if (currNode == null) { // add at first spot
      tableAdd[hashIndex] = new ListNode(name, data1, data2); // first in list
      numItems++; // brand new item
    } else {
      if (currNode.name.equals(name)) { // non unique item to add
        currNode.count++; // increment count as item added again
        currNode.table1.deepInsert(data1); // insert into deep table as at least one insert done
        currNode.table2.deepInsert(data2); // insert into deep table as at least one insert done
        return;
      }
      while (currNode.next != null) { // get to last node
        currNode = currNode.next;
        if (currNode.name.equals(name)) { // non unique item to add
          currNode.count++; // increment count as item added again
          currNode.table1.deepInsert(data1); // insert into deep table as at least one insert done
          currNode.table2.deepInsert(data2); // insert into deep table as at least one insert done
          return;
        }
      }
      currNode.next = new ListNode(name, data1, data2); // next is new node
      numItems++; // brand new item
    }
  }

  /**
   * Adds the given node to the given table. A method used for rehashing all the nodes so number of
   * unique items does not change.
   * 
   * @param tableAdd table to add node to
   * @param addNode  node to add
   */
  private void rehash(ListNode tableAdd[], ListNode addNode) {
    int newIndex = addNode.name.hashCode();
    newIndex = Math.abs(newIndex) % tableAdd.length;
    ListNode currNode = tableAdd[newIndex];
    if (currNode == null) { // add at new spot
      tableAdd[newIndex] =
          new ListNode(addNode.name, addNode.count, addNode.table1, addNode.table2);
      return;
    }
    while (currNode.next != null) { // get to last in bucket
      currNode = currNode.next;
    } // add last
    currNode.next = new ListNode(addNode.name, addNode.count, addNode.table1, addNode.table2);
  }

  /**
   * A method that helps resize table, doubles the size and adds 1. Then calls a method to rehash.
   */
  private void resize() {
    ListNode newTable[] = new ListNode[(2 * table.length) + 1]; // new table
    // rehash
    int total = 0; // check till all items added
    for (int checkIndex = 0; (checkIndex < table.length) && (total != numItems); checkIndex++) {
      // check each index till total items checked
      ListNode currNode = table[checkIndex];
      while (currNode != null) { // rehash
        rehash(newTable, currNode); // this method was created to make code look ordered
        total++; // one item added
        currNode = currNode.next;
      }
    }
    table = newTable; // set new table
  }

  /**
   * Helps get every item in table's name and count as a 2d array.
   * 
   * @return 2d array with each item's name and count
   */
  String[][] getTable() {
    String[][] ret = new String[numItems][2]; // exactly the size of items in table
    int total = 0;
    for (int index = 0; (index < table.length) && (total != numItems); index++) {
      ListNode currNode = table[index];
      while (currNode != null) { // name at index 0 and count at index 1
        ret[total][0] = currNode.name;
        ret[total][1] = "" + currNode.count;
        total++;
        currNode = currNode.next;
      }
    }
    return ret;
  }

  /**
   * Helps get every first corresponding data item's name and count in the first corresponding data
   * table for the given name. Returned as a 2d array.
   * 
   * @param name to find first corresponding data pairs for
   * @return 2d array with first corresponding name and count pairs for given name, return null if
   *         name not found
   */
  String[][] getData1(String name) {
    int hashIndex = name.hashCode();
    hashIndex = Math.abs(hashIndex) % table.length;
    ListNode current = table[hashIndex]; // find node with name
    while (current != null) {
      if (current.name.equals(name)) // reached point to access
        break;
      current = current.next;
    }
    if (current == null) // didn't find name
      return null;
    String[][] ret = new String[current.table1.deepNumItems][2]; // all deep items of table1
    int total = 0; // to quit when all items added
    for (int index = 0; (index < current.table1.deepTable.length)
        && (total != current.table1.deepNumItems); index++) {
      DeepNode currNode = current.table1.deepTable[index];
      while (currNode != null) { // check nodes of the table, 0 holds name and 1 holds count
        ret[total][0] = currNode.deepName;
        ret[total][1] = "" + currNode.deepCount;
        total++;
        currNode = currNode.deepNext;
      }
    }
    return ret;
  }

  /**
   * Helps get every second corresponding data item's name and count in the second corresponding
   * data table for the given name. Returned as a 2d array.
   * 
   * @param name to find second corresponding data pairs for
   * @return 2d array with second corresponding name and count pairs for given name, return null if
   *         name not found
   */
  String[][] getData2(String name) {
    int hashIndex = name.hashCode();
    hashIndex = Math.abs(hashIndex) % table.length;
    ListNode current = table[hashIndex];
    while (current != null) {
      if (current.name.equals(name)) // reached point to access
        break;
      current = current.next;
    }
    if (current == null) // didn't find name
      return null;
    String[][] ret = new String[current.table2.deepNumItems][2]; // all deep items of table2
    int total = 0; // to quit when all items added
    for (int index = 0; (index < current.table2.deepTable.length)
        && (total != current.table2.deepNumItems); index++) {
      DeepNode currNode = current.table2.deepTable[index];
      while (currNode != null) { // check nodes of the table, 0 holds name and 1 holds count
        ret[total][0] = currNode.deepName;
        ret[total][1] = "" + currNode.deepCount;
        total++;
        currNode = currNode.deepNext;
      }
    }
    return ret;
  }

  /**
   * Helps the user remove pair with given string name, data1 and data2. True if successful, else
   * false. To remove pair must be present.
   * 
   * @param name  item's name
   * @param data1 corresponding first data to remove
   * @param data2 corresponding second data to remove
   * @return true if removal successful else false
   */
  boolean remove(String name, String data1, String data2) {
    int hashIndex = name.hashCode();
    hashIndex = Math.abs(hashIndex) % table.length;
    ListNode current = table[hashIndex];
    if (current == null) // didn't find name
      return false;
    if (current.name.equals(name)) { // first to remove
      DeepNode deep1 = current.table1.deepGet(data1); // check if first corresponding data present
      if (deep1 == null)
        return false;
      DeepNode deep2 = current.table2.deepGet(data2); // check if second corresponding data present
      if (deep2 == null)
        return false;
      if (current.count == 1) { // one case of pairs with this name
        table[hashIndex] = current.next; // effectively deleting it, all at once
        numItems--; // last item with name deleted
      } else { // one name has many data1 and data2 fields
        current.count--; // reduced count means name removed but data1 and data2 need to be removed
        remove(deep1, deep2, current, data1, data2); // so call this helper
      }
      return true;
    }
    while (current.next != null) { // find point to remove
      if (current.next.name.equals(name)) { // reached point to delete, it's current.next
        DeepNode deep1 = current.next.table1.deepGet(data1);
        if (deep1 == null) // check if first corresponding data present
          return false;
        DeepNode deep2 = current.next.table2.deepGet(data2);
        if (deep2 == null) // check if second corresponding data present
          return false;
        if (current.next.count == 1) { // one valid entry must be deleted
          current.next = current.next.next; // effectively deleting it, all at once
          numItems--; // last item with name deleted
        } else { // one name has many data1 and data2 fields
          current.next.count--; // reduced count means name removed but data1 and data2 need to be
                                // removed, so call helper function for that
          remove(deep1, deep2, current.next, data1, data2);
        }
        return true;
      }
      current = current.next;
    }
    return false;
  }

  /**
   * A private helper function to remove deep nodes for a given current node.
   * 
   * @param deep1   deepNode from deep Table1 that helps remove data1 from deep Table1
   * @param deep2   deepNode from deep Table2 that helps remove data2 from deepTable2
   * @param current node for whom deepTable removal to perform
   * @param data1   corresponding first data to remove
   * @param data2   corresponding second data to remove
   */
  private void remove(DeepNode deep1, DeepNode deep2, ListNode current, String data1,
      String data2) {
    if (deep1.deepName.equals(data1)) { // deep1 is the first node in some index in deeptable1
      if (deep1.deepCount != 1) // count is not 1 so just decrease count to delete it
        deep1.deepCount--;
      else { // count is one so must remove completely
        int deepIndex1 = data1.hashCode();
        deepIndex1 = Math.abs(deepIndex1) % current.table1.deepTable.length;
        current.table1.deepTable[deepIndex1] = deep1.deepNext; // delete the first
        current.table1.deepNumItems--; // one less unique item
      }
    } else { // deep1 is some node after which is node to delete at some index in deeptable1
      if (deep1.deepNext.deepCount != 1) // count is not 1 so just decrease count to delete it
        deep1.deepNext.deepCount--;
      else { // count is 1 for delete node
        deep1.deepNext = deep1.deepNext.deepNext;
        current.table1.deepNumItems--; // one less unique item
      }
    }
    if (deep2.deepName.equals(data2)) { // deep2 is the first node in some index in deeptable2
      if (deep2.deepCount != 1) // count is not 1 so just decrease count to delete it
        deep2.deepCount--;
      else { // count is one so must remove completely
        int deepIndex2 = data2.hashCode();
        deepIndex2 = Math.abs(deepIndex2) % current.table2.deepTable.length;
        current.table2.deepTable[deepIndex2] = deep2.deepNext; // delete the first
        current.table2.deepNumItems--; // one less unique item
      }
    } else { // deep2 is some node after which is node to delete at some index in deeptable2
      if (deep2.deepNext.deepCount != 1) // count is not 1 so just decrease count to delete it
        deep2.deepNext.deepCount--;
      else { // count is 1 for delete node
        deep2.deepNext = deep2.deepNext.deepNext;
        current.table2.deepNumItems--; // one less unique item
      }

    }
  }
}
