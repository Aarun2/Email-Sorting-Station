///////////////////////// Main ////////////////////////////
//
// Title: Main for the GUI
// Course: CS 400, Summer 2020
//
// Author: Aditya Arun
// Email: aarun2@wisc.edu
// Lecturer's Name: Florian Heimerl
//
///////////////////////////////////////////////////////////
package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;;


/**
 * The class that builds the application to display windows of the email sorting station
 * 
 * @author Aditya
 *
 */
public class Main extends Application {

  // basic width and height
  private static final int WINDOW_WIDTH = 500;
  private static final int WINDOW_HEIGHT = 500;
  // Strings that store various status, error and title strings
  private static final String MAIN_TITLE = "EMAIL SORTING STATION";
  private static final String MAIN_DISPLAY = "DISPLAY";
  private static final String ADD_DISPLAY = "ADD ITEM";
  private static final String FILTER_DISPLAY = "FILTER/SELECT ITEM";
  private static final String REMOVE_DISPLAY = "REMOVE ITEM";
  private static final String SAVE_DISPLAY = "SAVE ALL ITEMS";
  private static final String ERROR_TITLE = "ERROR";
  private static final String STATUS_UPDATE = "STATUS UPDATE";
  private static final String FORMAT = "FORMAT NEEDED AT EACH LINE: FROM,TO,DATE";
  private static final String ITEM_NOT_PRESENT = "ITEM IS NOT PRESENT";
  private static final String GROUP_NOT_PRESENT = "GROUP TO DELETE NOT PRESENT";
  private static final String FILE_INVALID = "CHOSEN FILE CAN'T BE OPENED";
  private static final String FILE_UNREADABLE = "CHOSEN FILE CAN'T BE READ";
  private static final String SKIP =
      "NOTE: FIRST LINE IS SKIPPED. DATA AT FIRST LINE OF FILE IS NOT READ";

  // a list to store user inputs for quickly passing arguments to other methods
  private static ArrayList<String> userInputs = new ArrayList<String>();

  // tables for storing from, to and date data
  // stores from as main data and to and date as corresponding data
  private static HashTable fromTable = new HashTable();
  // stores to as main data and from and date as corresponding data
  private static HashTable toTable = new HashTable();
  // stores date as main data and from and to as corresponding data
  private static HashTable dateTable = new HashTable();

  /**
   * Build the Welcome page that let's the user import data or start with an empty database.
   * 
   * @param primaryStage provided by launch call in main
   */
  @Override
  public void start(Stage primaryStage) {

    // Welcome layout is Border Pane
    BorderPane root = new BorderPane();

    Label greetings = new Label("WELCOME!");
    Label format = new Label(FORMAT);
    Label skip = new Label(SKIP);
    Button load = new Button("Load Data (with extension: .csv)");
    Button fresh = new Button("Start With Empty Database");
    load.setOnAction(e -> fileSelect(primaryStage)); // user wants to load, get the file
    fresh.setOnAction(e -> {// user wants to start afresh, close this tab, get the main display
      primaryStage.close();
      getEmptyDisplay(); // to display the main page
    });
    VBox vbox = new VBox(greetings, format, skip, load, fresh);

    vbox.setAlignment(Pos.CENTER); // center align
    root.setCenter(vbox);

    Scene mainScene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);

    // Add the stuff and set the primary stage
    primaryStage.setTitle(MAIN_TITLE);
    primaryStage.setScene(mainScene);
    primaryStage.show();
  }

  /**
   * Creates an error window with the given message with dimensions multiple times width and height
   * constants
   * 
   * @param errorMessage message to print in window
   * @param multiple     to multiply to dimensions for size of window
   */
  private void errorTab(String errorMessage, double multiple) {
    Stage errorStage = new Stage();
    BorderPane errorPane = new BorderPane();
    Label error = new Label(errorMessage);
    errorPane.setCenter(error);
    BorderPane.setAlignment(error, Pos.CENTER);
    Scene errorScene = new Scene(errorPane, WINDOW_WIDTH * multiple, WINDOW_HEIGHT * multiple);

    // Add the stuff and set the stage
    errorStage.setTitle(ERROR_TITLE);
    errorStage.setScene(errorScene);
    errorStage.show();
  }

  /**
   * If .csv file chosen then close given stage and display contents. Else create error window.
   * 
   * @param primaryStage stage to close
   */
  private void fileSelect(Stage primaryStage) {
    // to load data from a file
    FileChooser fileChooser = new FileChooser();
    // only .csv
    fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("csv file", "*.csv"));
    File selectedFile = fileChooser.showOpenDialog(primaryStage); // helps user choose file
    if (selectedFile == null) { // no file was chosen by user
      errorTab(FILE_INVALID, 0.5);
      return;
    }
    primaryStage.close(); // correct extension, so display contents
    try {
      String row;
      BufferedReader csvReader = new BufferedReader(new FileReader(selectedFile.getAbsolutePath()));
      csvReader.readLine(); // first line is skipped
      while ((row = csvReader.readLine()) != null) {
        String[] data = row.split(",");
        if (data.length != 3) { // not the right length
          Stage newStage = new Stage();
          start(newStage); // give the user another chance
          errorTab(FORMAT, 1); // display the error tab
          csvReader.close();
          return;
        }
        fromTable.insert(data[0].trim(), data[1].trim(), data[2].trim()); // from(main) to(data1)
                                                                          // date(data2)
        toTable.insert(data[1].trim(), data[0].trim(), data[2].trim()); // to(main) from(data1)
                                                                        // date(data2)
        dateTable.insert(data[2].trim(), data[0].trim(), data[1].trim()); // date(main) from(data1)
                                                                          // to(data2)
      }
      csvReader.close();
    } catch (IOException excpt) {
      errorTab(FILE_UNREADABLE, 0.5); // some problem with readLine
      return;
    }
    getDisplay(); // display file contents as 3 charts
  }

  /**
   * Creates the main display window with the ADD_DISPLAY, OPEN_DISPLAY, REMOVE_DISPLAY,
   * SAVE_DISPLAY options on top. These options let the user add data to database, filter/select
   * data in database, remove data in database and save the database.
   *
   */
  private void getEmptyDisplay() {
    Stage displayStage = new Stage();
    BorderPane display = new BorderPane();
    Button add = new Button(ADD_DISPLAY);
    Button filter = new Button(FILTER_DISPLAY);
    Button remove = new Button(REMOVE_DISPLAY);
    Button save = new Button(SAVE_DISPLAY);
    // when button pressed those specific windows are created to help user do those tasks
    add.setOnAction(e -> getAddDisplay(displayStage));
    filter.setOnAction(e -> getFilterDisplay());
    remove.setOnAction(e -> getRemoveDisplay(displayStage));
    save.setOnAction(e -> saveStage());
    HBox topHbox = new HBox(add, filter, remove, save);
    topHbox.setAlignment(Pos.CENTER);
    BorderPane fromObject = new BorderPane();
    // An empty from Pie Chart:
    fromObject.setTop(new Label("From:"));
    PieChart fromChart = new PieChart();
    fromObject.setCenter(fromChart);
    BorderPane toObject = new BorderPane();
    // An empty to Pie Chart:
    toObject.setTop(new Label("To:"));
    PieChart toChart = new PieChart();
    toObject.setCenter(toChart);
    BorderPane dateObject = new BorderPane();
    // An empty date Pie Chart:
    dateObject.setTop(new Label("Date:"));
    PieChart dateChart = new PieChart();
    dateObject.setCenter(dateChart);
    HBox centerHbox = new HBox(fromObject, toObject, dateObject);
    display.setCenter(centerHbox); // charts in the center
    display.setTop(topHbox); // buttons on top
    Scene displayScene = new Scene(display, 2 * WINDOW_WIDTH, 2 * WINDOW_HEIGHT);
    displayStage.setTitle(MAIN_DISPLAY);
    displayStage.setScene(displayScene);
    displayStage.show();
  }

  /**
   * This method helps me save corresponding data for chosen selection. Selection 0: to save from's
   * to and date fields. Selection 1: to save to's from and date fields. Selection 2: to save date's
   * from and to fields. The selection field tells us the type of data passed through the userInputs
   * field (first item).
   * 
   * @param saveStage to let user select file to save to
   * @param selection 0 for from field, 1 for to field and 2 for date field
   */
  private void saveDatabase(Stage saveStage, int selection) {
    FileChooser fileChooser = new FileChooser();
    // only accepts .csv files
    fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("csv file", "*.csv"));
    File file = fileChooser.showSaveDialog(saveStage);
    try {// print an example data to file
      PrintWriter print = new PrintWriter(file);
      if (selection == 0) { // print from field's corresponding data fields
        String[][] printDatabase = fromTable.getData1(userInputs.get(0)); // to fields
        if (printDatabase != null) {
          print.println("From:," + userInputs.get(0));
          print.println("To,Count"); // print to fields that this from id sent mails to
          // with the number of email sent
          for (int index = 0; index < printDatabase.length; index++) {
            print.println(printDatabase[index][0] + "," + printDatabase[index][1]);
          }
          print.println();
        } else { // null returned if from field not found so invalid save
          errorTab(ITEM_NOT_PRESENT, 0.5);
          print.close();
          return;
        }
        printDatabase = fromTable.getData2(userInputs.get(0));
        if (printDatabase != null) {
          print.println("Date,Count"); // print dates fields that this from id sent mails
          // with the number of mails sent on each of those dates
          for (int index = 0; index < printDatabase.length; index++) {
            print.println(printDatabase[index][0] + "," + printDatabase[index][1]);
          }
        }
      } else if (selection == 1) { // print to field's corresponding fields
        String[][] printDatabase = toTable.getData1(userInputs.get(0));
        if (printDatabase != null) {
          print.println("To:," + userInputs.get(0));
          print.println("From,Count"); // print from id's that sent mails to this to id
          // and the number of mails received
          for (int index = 0; index < printDatabase.length; index++) {
            print.println(printDatabase[index][0] + "," + printDatabase[index][1]);
          }
          print.println();
        } else { // to id not found
          errorTab(ITEM_NOT_PRESENT, 0.5);
          print.close();
          return;
        }
        printDatabase = toTable.getData2(userInputs.get(0));
        if (printDatabase != null) {
          print.println("Date,Count"); // print dates, to id received mails
          // and number of mails received on each of those dates
          for (int index = 0; index < printDatabase.length; index++) {
            print.println(printDatabase[index][0] + "," + printDatabase[index][1]);
          }
        }
      } else { // print from and to fields for given date
        String[][] printDatabase = dateTable.getData1(userInputs.get(0));
        if (printDatabase != null) {
          print.println("Date:," + userInputs.get(0));
          print.println("From,Count"); // email senders on this day
          // and number of mails sent by that sender on this date
          for (int index = 0; index < printDatabase.length; index++) {
            print.println(printDatabase[index][0] + "," + printDatabase[index][1]);
          }
          print.println();
        } else { // date not found in database
          errorTab(ITEM_NOT_PRESENT, 0.5);
          print.close();
          return;
        }
        printDatabase = dateTable.getData2(userInputs.get(0));
        if (printDatabase != null) {
          print.println("To,Count"); // email receivers on this day
          // and number of mails received by that receiver on this date
          for (int index = 0; index < printDatabase.length; index++) {
            print.println(printDatabase[index][0] + "," + printDatabase[index][1]);
          }
        }
      }
      status("Save Successful!");
      print.close();
    } catch (FileNotFoundException e) {
      errorTab(FILE_INVALID, 0.5);
      return;
    }
  }

  /**
   * Creates stage for user to decide and save the chosen field's corresponding data.
   */
  private void saveStage() {
    Stage saveStage = new Stage();
    // To select the type
    RadioButton fromRadio = new RadioButton();
    RadioButton toRadio = new RadioButton();
    RadioButton dateRadio = new RadioButton();
    Label from = new Label("From: ");
    Label to = new Label("To: ");
    Label date = new Label("Date: ");
    // to enter the value
    TextField fromText = new TextField();
    TextField toText = new TextField();
    TextField dateText = new TextField();
    HBox fromBox = new HBox(fromRadio, from, fromText);
    HBox toBox = new HBox(toRadio, to, toText);
    HBox dateBox = new HBox(dateRadio, date, dateText);
    Button save = new Button("SAVE TO FILE"); // to enter choice
    save.setOnAction(e -> {
      userInputs = new ArrayList<String>();
      if (fromRadio.isSelected()) {
        userInputs.add(fromText.getText().trim());
        if (userInputs.get(0) == null || userInputs.get(0).length() == 0) {
          errorTab("Must have a From value to save for", 0.5); // selected but no value
          return;
        }
        saveDatabase(saveStage, 0); // save from's corresponding data
      } else if (toRadio.isSelected()) {
        userInputs.add(toText.getText().trim());
        if (userInputs.get(0) == null || userInputs.get(0).length() == 0) {
          errorTab("Must have a To value to save for", 0.5); // selected but no value
          return;
        }
        saveDatabase(saveStage, 1); // save to's corresponding data
      } else if (dateRadio.isSelected()) {
        userInputs.add(dateText.getText().trim());
        if (userInputs.get(0) == null || userInputs.get(0).length() == 0) {
          errorTab("Must have a Date value to save for", 0.5); // selected but no value
          return;
        }
        saveDatabase(saveStage, 2); // save date's corresponding data
      } else { // nothing selected
        this.errorTab("No field/item is selected", 0.5);
      }
    });
    VBox vbox = new VBox(fromBox, toBox, dateBox, save);
    BorderPane filterPane = new BorderPane();
    Label selectMessage = new Label("Select One Field/Item whose corresponding details to save");
    filterPane.setTop(selectMessage);
    filterPane.setCenter(vbox);
    BorderPane.setAlignment(selectMessage, Pos.CENTER);
    Scene addScene = new Scene(filterPane, WINDOW_WIDTH, WINDOW_HEIGHT);
    saveStage.setTitle(FILTER_DISPLAY);
    saveStage.setScene(addScene);
    saveStage.show();
  }

  /**
   * Creates the main display window with the ADD_DISPLAY, OPEN_DISPLAY, REMOVE_DISPLAY,
   * SAVE_DISPLAY options on top. These options let the user add data to database, filter/select
   * data in database, remove data in database and save the database. It also displays three charts
   * showing the frequency of From email addresses, To email addresses and Dates various email are
   * sent.
   */
  private void getDisplay() {
    Stage displayStage = new Stage();
    BorderPane display = new BorderPane();
    Button add = new Button(ADD_DISPLAY);
    Button filter = new Button(FILTER_DISPLAY);
    Button remove = new Button(REMOVE_DISPLAY);
    Button save = new Button(SAVE_DISPLAY);
    // when button pressed those specific windows are created to help user do those tasks
    add.setOnAction(e -> {
      getAddDisplay(displayStage);
    });
    filter.setOnAction(e -> getFilterDisplay());
    remove.setOnAction(e -> getRemoveDisplay(displayStage));
    save.setOnAction(e -> saveStage());
    HBox topHbox = new HBox(add, filter, remove, save);
    topHbox.setAlignment(Pos.CENTER);
    BorderPane fromObject = new BorderPane();
    fromObject.setTop(new Label("From:"));
    PieChart fromChart = new PieChart();
    String[][] checkTable = fromTable.getTable(); // get from id's and their counts
    for (int index = 0; index < checkTable.length; index++) { // add name and (string to count)
      PieChart.Data from =
          new PieChart.Data(checkTable[index][0], Integer.parseInt(checkTable[index][1]));
      fromChart.getData().add(from);
    }
    fromObject.setCenter(fromChart);
    BorderPane toObject = new BorderPane();
    toObject.setTop(new Label("To:"));
    PieChart toChart = new PieChart();
    checkTable = toTable.getTable(); // get to id's and their counts
    for (int index = 0; index < checkTable.length; index++) { // add name and (string to count)
      PieChart.Data to =
          new PieChart.Data(checkTable[index][0], Integer.parseInt(checkTable[index][1]));
      toChart.getData().add(to);
    }
    toObject.setCenter(toChart);
    BorderPane dateObject = new BorderPane();
    dateObject.setTop(new Label("Date:"));
    PieChart dateChart = new PieChart();
    checkTable = dateTable.getTable(); // get date id's and their counts
    for (int index = 0; index < checkTable.length; index++) { // add name and (string to count)
      PieChart.Data date =
          new PieChart.Data(checkTable[index][0], Integer.parseInt(checkTable[index][1]));
      dateChart.getData().add(date);
    }
    dateObject.setCenter(dateChart);
    HBox centerHbox = new HBox(fromObject, toObject, dateObject);
    display.setCenter(centerHbox); // charts in the center
    display.setTop(topHbox); // buttons on top
    Scene displayScene = new Scene(display, 4 * WINDOW_WIDTH, 4 * WINDOW_HEIGHT);
    displayStage.setTitle(MAIN_DISPLAY);
    displayStage.setScene(displayScene);
    displayStage.show();
  }

  /**
   * A method that is called to remind user that some change has taken place
   * 
   * @param message the change that has taken place
   */
  private void status(String message) {
    Stage statusStage = new Stage();
    BorderPane statusPane = new BorderPane();
    Label status = new Label(message);
    statusPane.setCenter(status); // set status
    BorderPane.setAlignment(status, Pos.CENTER);
    Scene errorScene = new Scene(statusPane, WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2);

    // Add the stuff and set the stage
    statusStage.setTitle(STATUS_UPDATE);
    statusStage.setScene(errorScene);
    statusStage.show();
  }

  /**
   * Creates a window that helps the user remove data from database.
   */
  private void getRemoveDisplay(Stage displayStage) {
    Stage removeStage = new Stage();
    Label from = new Label("From: ");
    Label to = new Label("To: ");
    Label date = new Label("Date: ");
    // field for user to enter data
    TextField fromText = new TextField();
    TextField toText = new TextField();
    TextField dateText = new TextField();
    HBox fromBox = new HBox(from, fromText);
    HBox toBox = new HBox(to, toText);
    HBox dateBox = new HBox(date, dateText);
    Button select = new Button("ENTER");
    select.setOnAction(e -> {// data entered get values
      userInputs = new ArrayList<String>();
      userInputs.add(fromText.getText().trim());
      userInputs.add(toText.getText().trim());
      userInputs.add(dateText.getText().trim());
      // check for valid input
      if (userInputs.get(0) == null || userInputs.get(0).length() == 0) {
        errorTab("Must have a From value to remove", 0.5);
        return;
      }
      if (userInputs.get(1) == null || userInputs.get(1).length() == 0) {
        errorTab("Must have a To value to remove", 0.5);
        return;
      }
      if (userInputs.get(2) == null || userInputs.get(2).length() == 0) {
        errorTab("Must have a Date value to remove", 0.5);
        return;
      } // now remove from each table
      boolean result = fromTable.remove(userInputs.get(0), userInputs.get(1), userInputs.get(2));
      if (!result) { // if a group in pair is not present
        errorTab(GROUP_NOT_PRESENT, 0.5);
        return;
      }
      // if present in one, must be present in others
      toTable.remove(userInputs.get(1), userInputs.get(0), userInputs.get(2));
      dateTable.remove(userInputs.get(2), userInputs.get(0), userInputs.get(1));
      getDisplay();
      displayStage.close();
      status("Removal Successful");
      removeStage.close();
    });
    VBox vbox = new VBox(fromBox, toBox, dateBox, select);
    vbox.setAlignment(Pos.CENTER);
    Scene removeScene = new Scene(vbox, WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2);
    removeStage.setTitle(REMOVE_DISPLAY);
    removeStage.setScene(removeScene);
    removeStage.show();
  }

  /**
   * Creates a window that helps the user add data to the database.
   */
  private void getAddDisplay(Stage displayStage) {
    Stage addStage = new Stage();
    Label from = new Label("From: ");
    Label to = new Label("To: ");
    Label date = new Label("Date: ");
    // field for user to enter data
    TextField fromText = new TextField();
    TextField toText = new TextField();
    TextField dateText = new TextField();
    HBox fromBox = new HBox(from, fromText);
    HBox toBox = new HBox(to, toText);
    HBox dateBox = new HBox(date, dateText);
    Button select = new Button("ENTER");
    select.setOnAction(e -> {
      userInputs = new ArrayList<String>();
      userInputs.add(fromText.getText().trim());
      userInputs.add(toText.getText().trim());
      userInputs.add(dateText.getText().trim());
      // check for valid input
      if (userInputs.get(0) == null || userInputs.get(0).length() == 0) {
        errorTab("Must have a From value to add", 0.5);
        return;
      }
      if (userInputs.get(1) == null || userInputs.get(1).length() == 0) {
        errorTab("Must have a To value to add", 0.5);
        return;
      }
      if (userInputs.get(2) == null || userInputs.get(2).length() == 0) {
        errorTab("Must have a Date value to add", 0.5);
        return;
      }
      // add to each table, for from: from, to, date
      // to: to, from, date
      // date: date, from, to
      fromTable.insert(userInputs.get(0), userInputs.get(1), userInputs.get(2));
      toTable.insert(userInputs.get(1), userInputs.get(0), userInputs.get(2));
      dateTable.insert(userInputs.get(2), userInputs.get(0), userInputs.get(1));
      getDisplay();
      displayStage.close();
      status("Addition Successful");
      addStage.close();
    });
    VBox vbox = new VBox(fromBox, toBox, dateBox, select);
    vbox.setAlignment(Pos.CENTER);
    Scene addScene = new Scene(vbox, WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2);
    addStage.setTitle(ADD_DISPLAY);
    addStage.setScene(addScene);
    addStage.show();
  }

  /**
   * Helps user filter/select charts for a From email, To email or Date.
   */
  private void getFilterDisplay() {
    // to open/select/filter data and to to view analysis and results for that data
    Stage filterStage = new Stage();
    // To select the type
    RadioButton fromRadio = new RadioButton();
    RadioButton toRadio = new RadioButton();
    RadioButton dateRadio = new RadioButton();
    Label from = new Label("From: ");
    Label to = new Label("To: ");
    Label date = new Label("Date: ");
    // to enter the value
    TextField fromText = new TextField();
    TextField toText = new TextField();
    TextField dateText = new TextField();
    HBox fromBox = new HBox(fromRadio, from, fromText);
    HBox toBox = new HBox(toRadio, to, toText);
    HBox dateBox = new HBox(dateRadio, date, dateText);
    Button select = new Button("ENTER"); // to enter choice
    select.setOnAction(e -> {
      userInputs = new ArrayList<String>();
      if (fromRadio.isSelected()) {
        userInputs.add(fromText.getText().trim());
        if (userInputs.get(0) == null || userInputs.get(0).length() == 0) {
          errorTab("Must have a From value to search for", 0.5); // selected but no value
          return;
        }
        filterStage.close();
        getFromSpecific(); // to display from value's charts
      } else if (toRadio.isSelected()) {
        userInputs.add(toText.getText().trim());
        if (userInputs.get(0) == null || userInputs.get(0).length() == 0) {
          errorTab("Must have a To value to search for", 0.5); // selected but no value
          return;
        }
        filterStage.close();
        getToSpecific(); // to display to value's charts
      } else if (dateRadio.isSelected()) {
        userInputs.add(dateText.getText().trim());
        if (userInputs.get(0) == null || userInputs.get(0).length() == 0) {
          errorTab("Must have a Date value to search for", 0.5); // selected but no value
          return;
        }
        filterStage.close();
        getDateSpecific(); // to display date value's charts
      } else { // nothing selected
        this.errorTab("No field/item is selected", 0.5);
      }
    });
    VBox vbox = new VBox(fromBox, toBox, dateBox, select);
    BorderPane filterPane = new BorderPane();
    Label selectMessage = new Label("Select One Field/Item");
    filterPane.setTop(selectMessage);
    filterPane.setCenter(vbox);
    BorderPane.setAlignment(selectMessage, Pos.CENTER);
    Scene addScene = new Scene(filterPane, WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2);
    filterStage.setTitle(FILTER_DISPLAY);
    filterStage.setScene(addScene);
    filterStage.show();
  }

  /**
   * For the given from value display the date and to charts. Value is in userInputs.get(0).
   */
  private void getFromSpecific() {
    Stage fromSpecific = new Stage();
    String[][] displayItems = fromTable.getData1(userInputs.get(0)); // get to fields
    if (displayItems == null) { // can't find this from id
      errorTab(ITEM_NOT_PRESENT, 0.5);
      return;
    }
    BorderPane toObject = new BorderPane();
    toObject.setTop(new Label("To:"));
    PieChart toChart = new PieChart();
    for (int index = 0; index < displayItems.length; index++) { // create chart with name and count
      PieChart.Data to =
          new PieChart.Data(displayItems[index][0], Integer.parseInt(displayItems[index][1]));
      toChart.getData().add(to);
    }
    toObject.setCenter(toChart);
    // get date fields, to valid so, this also must be valid
    displayItems = fromTable.getData2(userInputs.get(0));
    BorderPane dateObject = new BorderPane();
    dateObject.setTop(new Label("Date:"));
    PieChart dateChart = new PieChart();
    for (int index = 0; index < displayItems.length; index++) { // create chart with name and count
      PieChart.Data date =
          new PieChart.Data(displayItems[index][0], Integer.parseInt(displayItems[index][1]));
      dateChart.getData().add(date);
    }
    dateObject.setCenter(dateChart);
    HBox hbox = new HBox(toObject, dateObject);
    Scene specificScene = new Scene(hbox, 2 * WINDOW_WIDTH, 2 * WINDOW_HEIGHT);
    fromSpecific.setTitle("From: " + userInputs.get(0)); // set with given value
    fromSpecific.setScene(specificScene);
    fromSpecific.show();
  }

  /**
   * For the given To value display corresponding date and from values. Value is userInputs.get(0).
   */
  private void getToSpecific() {
    Stage toSpecific = new Stage();
    String[][] displayItems = toTable.getData1(userInputs.get(0)); // get from field
    if (displayItems == null) { // to field not present
      errorTab(ITEM_NOT_PRESENT, 0.5);
      return;
    }
    BorderPane fromObject = new BorderPane();
    fromObject.setTop(new Label("From:"));
    PieChart fromChart = new PieChart();
    for (int index = 0; index < displayItems.length; index++) { // add name and count
      PieChart.Data from =
          new PieChart.Data(displayItems[index][0], Integer.parseInt(displayItems[index][1]));
      fromChart.getData().add(from);
    }
    fromObject.setCenter(fromChart);
    displayItems = toTable.getData2(userInputs.get(0)); // get date field
    BorderPane dateObject = new BorderPane();
    dateObject.setTop(new Label("Date:"));
    PieChart dateChart = new PieChart();
    for (int index = 0; index < displayItems.length; index++) { // add name and count
      PieChart.Data date =
          new PieChart.Data(displayItems[index][0], Integer.parseInt(displayItems[index][1]));
      dateChart.getData().add(date);
    }
    dateObject.setCenter(dateChart);
    HBox hbox = new HBox(fromObject, dateObject);
    Scene specificScene = new Scene(hbox, 2 * WINDOW_WIDTH, 2 * WINDOW_HEIGHT);
    toSpecific.setTitle("To: " + userInputs.get(0)); // set with given value
    toSpecific.setScene(specificScene);
    toSpecific.show();
  }

  /**
   * For the given date value display the corresponding from and to values. Value is in
   * userInputs.get(0).
   */
  private void getDateSpecific() {
    Stage dateSpecific = new Stage();
    String[][] displayItems = dateTable.getData1(userInputs.get(0)); // get from field
    if (displayItems == null) { // date field not present
      errorTab(ITEM_NOT_PRESENT, 0.5);
      return;
    }
    BorderPane fromObject = new BorderPane();
    fromObject.setTop(new Label("From:"));
    PieChart fromChart = new PieChart();
    for (int index = 0; index < displayItems.length; index++) { // add name and count
      PieChart.Data from =
          new PieChart.Data(displayItems[index][0], Integer.parseInt(displayItems[index][1]));
      fromChart.getData().add(from);
    }
    fromObject.setCenter(fromChart);
    displayItems = dateTable.getData2(userInputs.get(0)); // get to field
    BorderPane toObject = new BorderPane();
    toObject.setTop(new Label("To:"));
    PieChart toChart = new PieChart();
    for (int index = 0; index < displayItems.length; index++) { // add name and count
      PieChart.Data to =
          new PieChart.Data(displayItems[index][0], Integer.parseInt(displayItems[index][1]));
      toChart.getData().add(to);
    }
    toObject.setCenter(toChart);
    HBox hbox = new HBox(fromObject, toObject);
    Scene specificScene = new Scene(hbox, 2 * WINDOW_WIDTH, 2 * WINDOW_HEIGHT);
    dateSpecific.setTitle("Date: " + userInputs.get(0));
    dateSpecific.setScene(specificScene);
    dateSpecific.show();
  }

  /**
   * The main class launches the application which calls the start method
   * 
   * @param args
   */
  public static void main(String[] args) {
    launch(args);
  }
}
