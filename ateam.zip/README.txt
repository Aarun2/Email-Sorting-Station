README

Course: cs400
Semester: Summer 2020
Project Name: Email Sorting Station
Student Name: Aditya Arun

Email: aarun2@wisc.edu

Other Notes or Comments to the Grader: 
This application helps the user sort mails, you can pass data on each line with the format: FROM,TO,DATE.
The From field corresponds to the sender's mail id, To the recipient's mail id and Date the day the email was sent.
You can start with an empty application or load data in with a csv file with FROM,TO,DATE on each line.
Then you can entries, remove entries, filter/select/open entries and save entries. The filter option lets the user
view corresponding data fields for selected field. So for a From id, the corresponding to and date id's.
The Save function lets a user save corresponding data for chosen field. A From id will store the to id's that
sent mails to this id and date mails were sent to this id. Also, saves the count or number of times to id sent mail
and number of mails sent on that date. No bugs present in application. Throws error windows and status windows.
Also, data at first line is skipped in file.

Bug Report: No bugs